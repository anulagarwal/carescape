using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockManager : MonoBehaviour
{
    public List<Block> allBlocks = new List<Block>();
    [SerializeField] Vector2 blockOffset;
    [SerializeField] Vector2 gridSize;
    [SerializeField] GameObject blockPrefab;

    // Add this function to add all BlockScript objects in the scene
    public void AddAllBlocksInScene()
    {
        Block[] blocksInScene = FindObjectsOfType<Block>();
        allBlocks.AddRange(blocksInScene);
    }

    public void RemoveAllBlocks()
    {
        foreach(Block b in allBlocks)
        {
            Destroy(b.gameObject);
        }
        allBlocks.Clear();
    }

    public void UpdateBlocks()
    {
        foreach (Block b in allBlocks)
        {
            b.UpdateBlock();
        }
    }

    // Add this function to resize the grid of blocks
    public void ResizeBlockGrid()
    {      
        for (int i = 0; i < allBlocks.Count; i++)
        {
            int x = i % (int)gridSize.x;
            int y = i / (int)gridSize.x;

            Vector3 newPosition = new Vector3(x * blockOffset.x, 0f, y * blockOffset.y);
            allBlocks[i].transform.position = newPosition;
        }
    }

    public void SpawnBlockGrid()
    {
        RemoveAllBlocks();
        for (int x = 0; x < gridSize.x; x++)
        {
            for (int y = 0; y < gridSize.y; y++)
            {
                Vector3 spawnPosition = new Vector3(x * blockOffset.x, 0f, y * blockOffset.y);
                GameObject newBlock = Instantiate(blockPrefab, spawnPosition, Quaternion.identity);
                newBlock.transform.SetParent(transform);
                Block blockScript = newBlock.GetComponent<Block>();

                if (blockScript != null)
                {
                    allBlocks.Add(blockScript);
                }
            }
        }
    }
   
}
